﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ThingsDirectory.Migrations
{
    public partial class fixdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
