﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ThingsDirectory.Migrations
{
    public partial class fix : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Thing_Category_CategoryId",
                table: "Thing");

            migrationBuilder.DropTable(
                name: "Category");

            migrationBuilder.DropIndex(
                name: "IX_Thing_CategoryId",
                table: "Thing");

            migrationBuilder.DropColumn(
                name: "CategoryId",
                table: "Thing");

            migrationBuilder.AddColumn<string>(
                name: "CategoryName",
                table: "Thing",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CategoryName",
                table: "Thing");

            migrationBuilder.AddColumn<int>(
                name: "CategoryId",
                table: "Thing",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Category",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Category", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Thing_CategoryId",
                table: "Thing",
                column: "CategoryId");

            migrationBuilder.AddForeignKey(
                name: "FK_Thing_Category_CategoryId",
                table: "Thing",
                column: "CategoryId",
                principalTable: "Category",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
