﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ThingsDirectory.Models;

namespace ThingsDirectory.Data
{
    public class ThingsDirectoryContext : DbContext
    {
        public ThingsDirectoryContext (DbContextOptions<ThingsDirectoryContext> options)
            : base(options)
        {
        }

        public DbSet<ThingsDirectory.Models.Thing> Thing { get; set; }
    }
}
