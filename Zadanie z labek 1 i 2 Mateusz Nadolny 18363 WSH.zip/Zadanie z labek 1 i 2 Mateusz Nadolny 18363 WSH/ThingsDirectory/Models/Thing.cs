﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ThingsDirectory.Models
{
    public class Thing
    {
        public int Id { get; set; }

        [Display(Name="Nazwa")]
        public string Name { get; set; }
        [Display(Name = "Nazwa kategorii")]
        public string CategoryName { get; set; }
        [Display(Name = "Data wydania")]
        [DataType(DataType.Date)]
        public DateTime ReleaseDate { get; set; }
        [Display(Name = "Nośnik przechowujący")]
        public string StorageMedium { get; set; }
        [Display(Name = "Opis")]
        public string Description { get; set; }
        [Display(Name = "Numer ewidencyjny")]
        public int RegistrationNumber { get; set; }
        [Display(Name = "Miejsce składowania")]
        public string StoragePlace { get; set; }
        [Display(Name = "Pożyczone")]
        public bool IsBorrowed { get; set; }
        [Display(Name = "Data oddania")]
        [DataType(DataType.Date)]
        public DateTime DropOffDate { get; set; }
    }
}
